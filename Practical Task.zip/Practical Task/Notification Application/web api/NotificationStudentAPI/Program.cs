using NotificationStudentAPI.Hubs;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddSignalR();
builder.Services.AddControllers();

// Add CORS  to communicate with the API
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(builder =>
    {
        builder.WithOrigins("http://localhost:8080", "http://localhost:8081", "https://student-app-seven.vercel.app", "https://notification-bell-app.vercel.app") //first two urls for local and second two for hosted apps
               .AllowAnyHeader()
               .AllowAnyMethod()
               .AllowCredentials();  
    });
});

var app = builder.Build();

// Enable CORS
app.UseCors();

app.MapControllers();
app.MapHub<NotificationHub>("/notificationHub");

app.Run();
