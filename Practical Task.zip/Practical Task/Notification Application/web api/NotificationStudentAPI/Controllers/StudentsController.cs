﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.SignalR;
using NotificationStudentAPI.Hubs;
using NotificationStudentAPI.Models;
using NotificationStudentAPI.Models;
/// <summary>
/// Student controller is responsible for adding a student to database and notifying users 
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class StudentsController : ControllerBase
{
    private readonly string _connectionString;
    private readonly IHubContext<NotificationHub> _hubContext;

    public StudentsController(IConfiguration configuration, IHubContext<NotificationHub> hubContext) //used to retrieve connection string 
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection");
        _hubContext = hubContext; //injects the SignalR hub for sending notifications
    }

    [HttpPost]
    public async Task<IActionResult> AddStudent([FromBody] Student student)
    {
        using (SqlConnection conn = new SqlConnection(_connectionString))
        {
            SqlCommand cmd = new SqlCommand("SPI_Student", conn)
            {
                CommandType = CommandType.StoredProcedure
            };

            cmd.Parameters.AddWithValue("@Name", student.Name);
            cmd.Parameters.AddWithValue("@Address", student.Address);
            cmd.Parameters.AddWithValue("@Class", student.Class);

            try
            {
                conn.Open();
                var result = await cmd.ExecuteScalarAsync();

                // Send notification via SignalR
                await _hubContext.Clients.All.SendAsync("ReceiveNotification", $"New student added: {student.Name}");

                return Ok(new { Message = "Student added successfully.", StudentId = result });
            }
            catch (SqlException ex)
            {
                return StatusCode(500, new { Message = "Error adding student", Details = ex.Message });
            }
        }
    }
}
