<template>
  <div id="app">
  <!--Form to submit student details-->
    <h1>Add Student</h1>
    <form @submit.prevent="submitStudent" class="form-container">
      <div class="form-group">
        <label for="name">Name:</label>
        <input v-model="student.name" type="text" id="name" required />
      </div>

      <div class="form-group">
        <label for="address">Address:</label>
        <input v-model="student.address" type="text" id="address" required />
      </div>

      <div class="form-group">
        <label for="class">Class:</label>
        <input v-model="student.class" type="text" id="class" required />
      </div>

      <button type="submit" class="submit-btn">Add Student</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      student: {
        name: '',
        address: '',
        class: '',
      },
    };
  },
  methods: {
    // Submits student data via API
    async submitStudent() {
      try {
        const response = await axios.post('https://notificationstudentapi20241006105521.azurewebsites.net/api/students', this.student);
        alert('' + response.data.message);
         // Clear form after successful submission
        this.student.name = '';
        this.student.address = '';
        this.student.class = '';
      } catch (error) {
        console.error('Error adding student:', error);
        alert('Failed to add student.');
      }
    },
  },
};
</script>
<style scoped>
h1 {
  text-align: center;
  font-size: 2.5rem;
  color: #333;
  margin-bottom: 20px;
  font-family: 'Arial', sans-serif;
}

.form-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  max-width: 400px;
  margin: 50px auto;
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.form-group {
  display: flex;
  flex-direction: column;
  width: 100%;
  margin-bottom: 15px;
}

label {
  font-size: 1.1rem;
  color: #666;
  margin-bottom: 5px;
}

input[type="text"] {
  padding: 10px;
  font-size: 1rem;
  border: 1px solid #ccc;
  border-radius: 5px;
  width: 100%;
  transition: border-color 0.3s;
}

input[type="text"]:focus {
  border-color: #007BFF;
  outline: none;
}

.submit-btn {
  padding: 12px 20px;
  font-size: 1.2rem;
  background-color: #007BFF;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  width: 100%;
  transition: background-color 0.3s;
}

.submit-btn:hover {
  background-color: #0056b3;
}

.submit-btn:active {
  background-color: #004085;
  box-shadow: 0 2px #003366;
  transform: translateY(2px);
}
</style>
