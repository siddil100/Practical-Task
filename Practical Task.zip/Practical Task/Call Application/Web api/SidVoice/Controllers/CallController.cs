﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;


namespace SidVoice.Controllers
{
    /// <summary>
    /// The call controller  is resposible for managing calls
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class CallController : ControllerBase
    {
        private readonly string _accountSid = "AC170d633a0a037c61272fa71237799d89";
        private readonly string _authToken = "9abaff8653e70a41c9f78d4dc855037c";
        private readonly string _twilioPhoneNumber = "+12706400200";
        private readonly IHubContext<CallHub> _hubContext;

        public CallController(IHubContext<CallHub> hubContext)
        {
            _hubContext = hubContext;
            TwilioClient.Init(_accountSid, _authToken);
        }

        [HttpPost("makeCall")]
        public IActionResult MakeCall([FromBody] string toPhoneNumber)
        {
            var call = CallResource.Create(
                to: new PhoneNumber(toPhoneNumber),
                from: new PhoneNumber(_twilioPhoneNumber),
                url: new Uri("https://sidvoice20241004183650.azurewebsites.net/api/call/makeCall")
            );
            return Ok(call.Sid);
        }

        [HttpPost("voice")]
        public IActionResult Voice()
        {
            var response = new Twilio.TwiML.VoiceResponse();
            response.Say("This is a call from your Vue.js app.");
            return Content(response.ToString(), "application/xml");
        }

        [HttpPost("mute")]
        public IActionResult MuteCall([FromBody] string callSid)
        {
            var call = CallResource.Update(
                status: CallResource.UpdateStatusEnum.Completed,
                pathSid: callSid
            );
            return Ok(call.Sid);
        }


        [HttpPost("simulateIncomingCall")]
        public async Task<IActionResult> SimulateIncomingCall()
        {
            var call = CallResource.Create(
                to: new PhoneNumber(_twilioPhoneNumber),
                from: new PhoneNumber("+919207383527"), 
                url: new Uri("https://sidvoice20241004183650.azurewebsites.net/api/call/voice") // voice endpoint
            );

            // Notify the frontend about the incoming call
            await _hubContext.Clients.All.SendAsync("ReceiveCall", call.Sid, "+919207383527");

            return Ok(new { callSid = call.Sid });
        }

    }
}
