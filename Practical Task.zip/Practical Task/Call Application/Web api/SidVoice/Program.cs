var builder = WebApplication.CreateBuilder(args);


builder.Services.AddControllers();

// Add CORS policy for Vue.js app
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowVueApp", builder =>
    {
        builder.WithOrigins("http://localhost:8080", "https://sidvue-project.vercel.app") //frontend URLfirst one for local and second one for hosted app
               .AllowAnyHeader()
               .AllowAnyMethod()
               .AllowCredentials(); 
    });
});

// Add SignalR support
builder.Services.AddSignalR();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();


app.UseCors("AllowVueApp");

app.UseAuthorization();


app.MapControllers();


app.MapHub<CallHub>("/callHub");

app.Run();
