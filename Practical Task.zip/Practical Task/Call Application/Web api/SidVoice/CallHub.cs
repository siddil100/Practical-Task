﻿using Microsoft.AspNetCore.SignalR;

public class CallHub : Hub
{
    public async Task NotifyIncomingCall(string callSid, string from)
    {
        await Clients.All.SendAsync("ReceiveCall", callSid, from);
    }
}
