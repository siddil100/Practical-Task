<template>
  <!--main template for the call toolbar -->
  <div class="call-toolbar-container">
    <div class="call-toolbar">
      <button @click="receiveCall">Receive Call</button>
      <button @click="dialCall">Dial Call</button>
      <button @click="toggleMute">{{ isMuted ? "Unmute" : "Mute" }}</button>
      <button @click="togglePause">{{ isPaused ? "Continue" : "Pause" }}</button>
    </div>

    <!-- Displays incoming call information -->
    <div v-if="incomingCall" class="incoming-call">
      <p>Incoming call from: {{ incomingCall.from }}</p>
      <div class="incoming-call-actions">
        <!-- Button to accept the incoming call -->
        <button class="accept-btn" @click="acceptCall">Accept</button>
        <!-- Button to reject the incoming call -->
        <button class="reject-btn" @click="rejectCall">Reject</button>
      </div>
    </div>

    <!-- Toast notification for call acceptance/rejection -->
    <div v-if="toastMessage" class="toast">
      <p>{{ toastMessage }}</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import * as signalR from '@microsoft/signalr';

export default {
  data() {
    return {
      // Variables to track call states
      isMuted: false,
      isPaused: false,
      callSid: null, // Call ID
      incomingCall: null, // Incoming call details
      connection: null, // SignalR connection
      toastMessage: null, // Toast message to display call actions
    };
  },
  
  // Setup SignalR connection when the component is created
  created() {
    this.setupSignalRConnection();
  },
  
  methods: {
    // Function to set up the SignalR connection and listen for incoming calls
    async setupSignalRConnection() {
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl('https://sidvoice20241004183650.azurewebsites.net/callHub') // SignalR hub URL
        .build();

      // Listen for the 'ReceiveCall' event from SignalR
      this.connection.on('ReceiveCall', (callSid, from) => {
        this.incomingCall = { callSid, from };
        console.log(`Incoming call from ${from}, callSid: ${callSid}`);
      });

      try {
        // Establish the SignalR connection
        await this.connection.start();
        console.log('SignalR connection established successfully');
      } catch (error) {
        console.error('Error establishing SignalR connection:', error);
      }
    },

    // Function to dial a call using an API call
    async dialCall() {
      const phoneNumber = prompt('Enter the phone number to call:');
      if (!phoneNumber) return;
      try {
        // Make a POST request to dial the call
        const response = await axios.post(
          'https://sidvoice20241004183650.azurewebsites.net/api/call/makeCall', 
          phoneNumber, 
          { headers: { 'Content-Type': 'application/json' } }
        );
        this.callSid = response.data; // Store the callSid of the dialed call
        alert('Calling...');
      } catch (error) {
        console.error('Error making call:', error);
      }
    },

    
    receiveCall() {
      alert('Ready to receive calls.');
    },

    // Function to mute or unmute the call using an API call
    async toggleMute() {
      if (!this.callSid) return;
      try {
        // Make a POST request to mute/unmute the call
        await axios.post('https://sidvoice20241004183650.azurewebsites.net/api/call/mute', { callSid: this.callSid });
        this.isMuted = !this.isMuted; 
      } catch (error) {
        console.error('Error toggling mute:', error);
      }
    },

    // Function to toggle the paused state of the call
    togglePause() {
      this.isPaused = !this.isPaused;
    },

    // Function to accept an incoming call
    acceptCall() {
      this.showToast('Call accepted');
      this.incomingCall = null; // Clear the incoming call details
    },

    //Function to reject an incoming call
    rejectCall() {
      this.showToast('Call rejected');
      this.incomingCall = null; // Clear the incoming call details
    },

    //Function to show a toast notification
    showToast(message) {
      this.toastMessage = message; // Set the toast message
      setTimeout(() => {
        this.toastMessage = null; // Hide the toast 
      }, 3000);
    }
  }
};
</script>

<style scoped>
/* Container for the call toolbar */
.call-toolbar-container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  height: 100vh;
}

/* Styles for the buttons in the call toolbar */
.call-toolbar {
  display: flex;
  gap: 10px;
  justify-content: center;
}

button {
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
  border: none;
  border-radius: 5px;
  transition: background-color 0.3s;
}

/* Styles for accept and reject buttons */
.accept-btn {
  background-color: #28a745; 
  color: white;
}

.accept-btn:hover {
  background-color: #218838;
}

.reject-btn {
  background-color: #dc3545; 
  color: white;
}

.reject-btn:hover {
  background-color: #c82333;
}

/* Styles for displaying incoming call information */
.incoming-call {
  margin-top: 20px;
  background-color: #f0f0f0;
  padding: 10px;
  border-radius: 5px;
  text-align: center;
}

.incoming-call-actions {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 10px;
}

/* Styles for the toast notification */
.toast {
  position: fixed;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  background-color: #333;
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
  opacity: 0.9;
  text-align: center;
}
</style>
